#ifndef PESQUISAPESSOASLIB_H_INCLUDED
#define PESQUISAPESSOASLIB_H_INCLUDED

/** Função para pesquisar cliente */
void procurarCliente();

/** Função para pesquisar funcionário */
void procurarFuncionario();

#endif // PESQUISAPESSOASLIB_H_INCLUDED
